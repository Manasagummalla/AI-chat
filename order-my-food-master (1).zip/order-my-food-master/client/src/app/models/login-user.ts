export interface ILoginUser {
    email: string,
    password: string
}