export interface ISortOption {
    value: string,
    viewValue: string,
  }