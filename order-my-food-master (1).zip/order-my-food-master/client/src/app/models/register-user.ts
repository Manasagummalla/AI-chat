export interface IRegisterUser {
    email: string,
    username: string,
    password: string
}