export interface IMenu {
    id: number,
    name: string,
    desc: string,
    price: number
}